function ss = suffStats(data)
%ss = suffStats(data)

% Compute the sufficient statistics for Ising pairwise MRF learning
% FILL ME IN!

A = data * data.';

M = size(A, 1); 
ss = sum(data, 2).'; 

for m = 2:M
      ss = [ss, A(m:13,(m-1)).'];

end
end