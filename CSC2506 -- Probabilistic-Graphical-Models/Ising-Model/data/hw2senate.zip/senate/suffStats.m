function ss = suffStats(data)
%ss = suffStats(data)

% Compute the sufficient statistics for Ising pairwise MRF learning
% FILL ME IN!

end


